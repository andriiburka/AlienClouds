
// PLACEHOLDERS UPLOAD PAGE

const form_fields = document.getElementsByTagName('input');
form_fields[1].placeholder = 'Project name:';
form_fields[2].placeholder = 'Description';
